#python

if __name__ == "__main__":

    import ccdb
    # import ccdb.ccdb_pyllapi
    ccdb.init_ccdb_console()
