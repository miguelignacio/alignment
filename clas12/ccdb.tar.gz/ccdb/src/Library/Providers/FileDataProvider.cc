#include "CCDB/Providers/FileDataProvider.h"
namespace ccdb
{



FileDataProvider::FileDataProvider(void)
{

}


FileDataProvider::~FileDataProvider(void)
{
}

bool FileDataProvider::Connect( std::string connectionString )
{
	//
	return false;

}

void FileDataProvider::Disconnect()
{
	//


}
}
