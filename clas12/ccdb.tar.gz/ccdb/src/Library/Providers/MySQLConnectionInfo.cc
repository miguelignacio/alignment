#include "CCDB/Providers/MySQLConnectionInfo.h"

namespace ccdb
{

}

